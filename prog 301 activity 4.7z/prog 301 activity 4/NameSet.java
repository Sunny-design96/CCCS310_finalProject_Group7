/*
 * 10/24/2024
 * Stanley Gee-Silverman assignement 4 for 310
 */

import java.util.HashSet;
import java.util.Scanner;

public class NameSet {
    private HashSet<String> names;

    public NameSet() {
        names = new HashSet<>();
    }

    // Method to add names to the set
    public void addNames(Scanner scanner) {
        String input;

        // Input Loop for adding names
        System.out.println("Add a name to the set, type 'end' to terminate input:");
        while (!(input = scanner.nextLine()).equalsIgnoreCase("end")) {
            if (names.add(input)) {
                System.out.println(input + " inserted.");
            } else {
                System.out.println(input + " already exists in the set.");
            }
            System.out.println("Add another name, or type 'end' to terminate input:");
        }
    }

    // Method to search for names in the set
    public void searchNames(Scanner scanner) {
        String input;

        // Search Loop for searching names
        System.out.println("Search for a name, type 'end' to terminate searching:");
        while (!(input = scanner.nextLine()).equalsIgnoreCase("end")) {
            if (names.contains(input)) {
                System.out.println(input + " found in the set.");
            } else {
                System.out.println(input + " not found in the set.");
            }
            System.out.println("Search for another name, or type 'end' to terminate searching:");
        }
    }
}
