import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        NameSet nameSet = new NameSet();  // Instantiate NameSet
        Scanner scanner = new Scanner(System.in);  // Create Scanner

        // Call methods to add names and search names
        nameSet.addNames(scanner);
        nameSet.searchNames(scanner);

        // Close Scanner
        scanner.close();
    }
}
