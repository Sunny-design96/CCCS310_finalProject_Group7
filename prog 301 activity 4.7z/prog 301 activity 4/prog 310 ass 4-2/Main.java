import java.util.ArrayList;
import java.util.Collections;

public class Main {
    public static void main(String[] args) {
        // Create a list of accounts
        ArrayList<Account> accounts = new ArrayList<>();
        accounts.add(new Account(101, "Eric", "Letterman", 500.0));
        accounts.add(new Account(102, "John", "Jones", 55000.0));
        accounts.add(new Account(103, "Patrick", "Parker", 28000.0));

        // Sort accounts by balance in descending order using AccountComparator
        Collections.sort(accounts, new AccountComparator());

        // Display sorted accounts
        for (Account account : accounts) {
            System.out.println(account.getFirstName() + " " + account.getLastName() + ": " + account.getBalance());
        }
    }
}
